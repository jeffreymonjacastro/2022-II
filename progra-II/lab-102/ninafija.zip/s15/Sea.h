#ifndef P2_CPP_SEA_H
#define P2_CPP_SEA_H

#include "Enviroment.h"

class Sea: Enviroment {

};

#endif //P2_CPP_SEA_H

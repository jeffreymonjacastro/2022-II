#ifndef P2_CPP_TYPE_H
#define P2_CPP_TYPE_H

#include <iostream>

using namespace std;

using s = string;
using i = int;
using d = double;
using c = char;


#endif //P2_CPP_TYPE_H

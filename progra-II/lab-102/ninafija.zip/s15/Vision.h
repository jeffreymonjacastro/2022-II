#ifndef P2_CPP_VISION_H
#define P2_CPP_VISION_H

#include <iostream>
#include "Type.h"
#include "Sensor.h"

using namespace std;

class Vision: Sensor {
private:
    i fps;
    i angulo_apertura;
    i resolucion;
public:

};

#endif //P2_CPP_VISION_H

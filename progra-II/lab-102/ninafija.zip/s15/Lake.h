#ifndef P2_CPP_LAKE_H
#define P2_CPP_LAKE_H

#include "Enviroment.h"

class Lake: Enviroment {

};


#endif //P2_CPP_LAKE_H
